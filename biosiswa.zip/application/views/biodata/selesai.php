<header class="header">
    <div class="container-fluid">
        <div class="container-xl">
            <div class="row">
                <div class="col-lg-1">
                    <img src="<?= base_url('asset/img/'); ?>logo.png" alt="">
                </div>
                <div class="col-lg-11">
                    <h2 class="brand">SMA NEGERI 1 RAWAMERTA</h2>
                </div>
            </div>
        </div>
    </div>
</header>

<section class="content">
    <div class="container-xl">
        <div class="row mt-5">
            <div class="col-lg-12 text-center">
                <h2 class="done">
                    <?= $subjudul; ?><br>
                    <?= $sub; ?><br>
                    <?= $done; ?>
                </h2>
            </div>
        </div>
    </div>
</section>